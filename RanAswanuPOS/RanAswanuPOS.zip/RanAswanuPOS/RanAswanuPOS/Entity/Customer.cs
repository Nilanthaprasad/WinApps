﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RanAswanuPOS.Entity
{
    class Customer
    {
        private long customerID;
        private String firstName;
        private String lastName;
        private String city;
        private String email;
        private String postCode;

        public long CustomerID { get => customerID; set => customerID = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string City { get => city; set => city = value; }
        public string Email { get => email; set => email = value; }
        public string PostCode { get => postCode; set => postCode = value; }

        public Customer(long customerID, String firstName, String lastName, String email, String postCode, String city)
        {
            this.customerID = customerID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.city = city;
            this.email = email;
            this.postCode = postCode;
        }



    }
}
