﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RanAswanuPOS.Entity;
using RanAswanuPOS.DataConn;
using MySql.Data.MySqlClient;

namespace RanAswanuPOS.EntityDao
{
    class OrderItemDao
    {
        private MySqlConnection dbCon;


        public OrderItemDao()
        {
            dbCon = DatabaseConnection.getConnection();
        }

        public List<OrderItem> getOrderItems(int orderId)
        {
            try
            {
                String query1 = "SELECT  " + DataDictionary.ORDER_ITEM_TABLE_ORDER_ITEM_ID + ", " + DataDictionary.ORDER_ITEM_TABLE_ORDER_ITEM_NAME +
                                 " FROM " + DataDictionary.ORDER_ITEM_TABLE +
                                 " WHERE " + DataDictionary.ORDER_ITEM_TABLE_ORDER_ID + " = @orderid" +
                                 " AND " + DataDictionary.ORDER_ITEM_TABLE_ORDER_ITEM_TYPE + " <> 'shipping'";

                //Create a list to store the result
                List<OrderItem> orderItemList = new List<OrderItem>();
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query1, dbCon);

                cmd.Parameters.AddWithValue("@orderid", orderId);

                MySqlDataReader dataReader = cmd.ExecuteReader();
                //Read the data and store them in the list

                String orderItemName;
                int orderItemId;
                int productId = 0;
                int quantity=0;
                double lineSubtotal=0;
                double lineTotal=0;
                OrderItem orderitem;
                Product prod;
                List<String> orderItemNames = new List<string>();
                List<int> orderItemIds = new List<int>();
                while (dataReader.Read())
                {
                    orderItemNames.Add(dataReader.GetString(1));
                    orderItemIds.Add(dataReader.GetInt32(0));

                }

                //close Data Reader
                dataReader.Close();

                //String query3 = "SELECT a.order_item_id, b.min_price  FROM _0kg_wc_order_product_lookup as a, _0kg_wc_product_meta_lookup as b " +
                //                "WHERE a.order_id = @orderid AND b.product_id = @

                //-----------------------
                int i = 0;

                while (i < orderItemNames.Count)
                {
                    String query2 = "SELECT a.meta_key, a.meta_value from _0kg_woocommerce_order_itemmeta as a WHERE (a.order_item_id = @orderitemid and a.meta_key = '_product_id') OR(a.order_item_id = @orderitemid and a.meta_key = '_qty') OR" +
                       "(a.order_item_id = @orderitemid and a.meta_key = '_line_subtotal') OR (a.order_item_id = @orderitemid and a.meta_key = '_line_total') ORDER BY a.order_item_id";

                    MySqlCommand cmd2 = new MySqlCommand(query2, dbCon);

                    cmd2.Parameters.AddWithValue("@orderitemid", orderItemIds[i]);

                    MySqlDataReader dataReader2 = cmd2.ExecuteReader();

                    //_line_subtotal
                    //_line_total
                    //_product_id
                    //_qty
                    while (dataReader2.Read())
                    {
                        switch (dataReader2.GetString(0))
                        {
                            case "_line_subtotal":
                                lineSubtotal = dataReader2.GetInt32(1);
                                break;
                            case "_line_total":
                                lineTotal = dataReader2.GetInt32(1);
                                break;
                            case "_product_id":
                                productId = dataReader2.GetInt32(1);
                                break;
                            case "_qty":
                                quantity = dataReader2.GetInt32(1);
                                break;
                        }
                        
                    }
                    prod = new Product(productId, orderItemNames[i]);
                    orderitem = new OrderItem(prod, quantity, lineSubtotal, lineTotal);
                    orderItemList.Add(orderitem);
                    dataReader2.Close();
                    //creating the product object
                    i++;

                }
                //---------------------------------------
                //return list to be displayed
                return orderItemList;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return null;
        }
    }
}
