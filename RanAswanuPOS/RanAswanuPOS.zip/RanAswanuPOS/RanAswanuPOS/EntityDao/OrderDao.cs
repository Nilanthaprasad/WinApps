﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using RanAswanuPOS.DataConn;
using RanAswanuPOS.Entity;


namespace RanAswanuPOS.EntityDao
{
    class OrderDao
    {
        private MySqlConnection dbCon;

        
        public OrderDao()
        {
            dbCon = DatabaseConnection.getConnection();
        }

        public List<Order> getAllOrders()
        {

            String[] columnList = { DataDictionary.ORDER_TABLE_COL_ORDER_ID,
                                    DataDictionary.ORDER_TABLE_COL_DATE_CREATED,
                                    DataDictionary.ORDER_TABLE_COL_CUSTOMER_ID,
                                    DataDictionary.ORDER_TABLE_COL_NUM_ITEMS_SOLD,
                                    DataDictionary.ORDER_TABLE_COL_NET_TOTAL,
                                    DataDictionary.ORDER_TABLE_COL_SHIPPING_TOTAL,
                                    DataDictionary.ORDER_TABLE_COL_TOTAL_SALES,
                                    DataDictionary.ORDER_TABLE_COL_STATUS};

            String query = DatabaseUtil.getSelectStatementWithColumns(DataDictionary.ORDER_TABLE, columnList);

            //Create a list to store the result
            List<Order> orderList = new List<Order>();

            //Create Command
            MySqlCommand cmd = new MySqlCommand(query, dbCon);

            //Create a data reader and Execute the command
            MySqlDataReader dataReader = cmd.ExecuteReader();

            //Read the data and store them in the list

            while (dataReader.Read())
            {
                orderList.Add(new Order(dataReader.GetInt32(0), dataReader.GetDateTime(1), dataReader.GetInt32(2), "Customer",
                                dataReader.GetInt32(3), dataReader.GetDouble(4), dataReader.GetDouble(5), 
                                dataReader.GetDouble(6), dataReader.GetString(7)));
            }

            //close Data Reader
            dataReader.Close();

            //close Connection
            //dbCon.Close();

            //return list to be displayed
            return orderList;
        }

        public List<Order> getAllOrdersWithDateRangeAndCustomerNames(DateTime startDate, DateTime endDate)
        {
            String startDateparamvalue = "'" + startDate.Year + "-" + startDate.Month + "-" + startDate.Day + "'";
            String endDateParamValue = "'" + endDate.Year + "-" + endDate.Month + "-" + endDate.Day + "'";
           
            String query = "Select " + DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_ORDER_ID + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_DATE_CREATED + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_CUSTOMER_ID + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_NUM_ITEMS_SOLD + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_NET_TOTAL + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_SHIPPING_TOTAL + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_TOTAL_SALES + ", " +
                            DataDictionary.ORDER_TABLE + "." + DataDictionary.ORDER_TABLE_COL_STATUS + ", " +

                             //Adding the data from customer column
                             DataDictionary.CUSTOMER_TABLE + "." + DataDictionary.CUSTOMER_TABLE_COL_FIRST_NAME + "," +
                             DataDictionary.CUSTOMER_TABLE + "." + DataDictionary.CUSTOMER_TABLE_COL_LAST_NAME + "," +
                             DataDictionary.CUSTOMER_TABLE + "." + DataDictionary.CUSTOMER_TABLE_COL_EMAIL + "," +
                             DataDictionary.CUSTOMER_TABLE + "." + DataDictionary.CUSTOMER_TABLE_COL_POST_CODE + "," +
                             DataDictionary.CUSTOMER_TABLE + "." + DataDictionary.CUSTOMER_TABLE_COL_CITY +

                             " FROM " + DataDictionary.ORDER_TABLE + ", " + DataDictionary.CUSTOMER_TABLE +
                             " WHERE " + DataDictionary.ORDER_TABLE+"." +DataDictionary.ORDER_TABLE_COL_CUSTOMER_ID + " = " +
                                    DataDictionary.CUSTOMER_TABLE + "."+ DataDictionary.CUSTOMER_TABLE_COL_CUSTOMER_ID + 
                               " AND " + DataDictionary.ORDER_TABLE+"."+DataDictionary.ORDER_TABLE_COL_DATE_CREATED +
                               " BETWEEN " + "CAST( "+startDateparamvalue+" AS DATE) AND " + "CAST( "+ endDateParamValue + " AS DATE)";
            //" BETWEEN " + "CAST( @startdate AS DATE) AND " + "CAST( @enddate AS DATE)";

           

            //Create a list to store the result
            List < Order> orderList = new List<Order>();
            //Create Command
            MySqlCommand cmd = new MySqlCommand(query, dbCon);
            
            //cmd.Parameters.AddWithValue("@startdate", startDateparamvalue);
            //cmd.Parameters.AddWithValue("@enddate", endDateParamValue);
            //Create a data reader and Execute the command
            MySqlDataReader dataReader = cmd.ExecuteReader();
            //Read the data and store them in the list
            while (dataReader.Read())
            {

                orderList.Add(new Order(dataReader.GetInt32(0),
                                        dataReader.GetDateTime(1), 
                                        dataReader.GetInt32(2), 
                                        dataReader.GetInt32(3),
                                        dataReader.GetDouble(4),
                                        dataReader.GetDouble(5),
                                        dataReader.GetDouble(6), 
                                        dataReader.GetString(7),
                                        
                                        new Customer(dataReader.GetInt32(2), 
                                                    dataReader.GetString(8), 
                                                    dataReader.GetString(9), 
                                                    dataReader.GetString(10),
                                                    dataReader.GetString(11), 
                                                    dataReader.GetString(12))));
            }

            //close Data Reader
            dataReader.Close();

            //close Connection
            //dbCon.Close();

            //return list to be displayed
            return orderList;
        }
    }
}
