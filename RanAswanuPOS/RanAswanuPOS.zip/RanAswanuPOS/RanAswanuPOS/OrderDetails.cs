﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RanAswanuPOS.Entity;

namespace RanAswanuPOS
{
    public partial class OrderDetails : Form
    {
        public OrderDetails(int orderId, String customerFirstName, String customerLastName, double total)
        {
            InitializeComponent();
            loadGrid(orderId);
            lblCustomerName.Text = customerFirstName + " " + customerLastName;
            lblTotalPrice.Text = total.ToString();
        }

        public void loadGrid(int orderId)
        {
            List<OrderItem> orderItems = OrderItem.getOrderItems(orderId);

            if (orderItems.Count > 0)
            {
                int i = 0;
                OrderItem orderItem;
                while (i < orderItems.Count)
                {
                    orderItem = (OrderItem)orderItems[i];

                    dgvOrderDetails.Rows.Add(++i, orderItem.Product.ProductId, orderItem.Product.ProductName, orderItem.LineTotal/ orderItem.Quantity, orderItem.Quantity, orderItem.LineTotal);
                    
                }
                dgvOrderDetails.Rows.Add(++i, "", "Transport Cost", 250, 1, 250);
            }


        }
    }
}
